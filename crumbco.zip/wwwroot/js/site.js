document.addEventListener('DOMContentLoaded', () => {
  const menu = document.querySelector('.menu-toggle');
  const navigation = document.querySelector('.main-nav');
  menu?.addEventListener('click', () => {
    const expanded = menu.getAttribute('aria-expanded') === 'true';
    menu.setAttribute('aria-expanded', String(!expanded));
    menu.setAttribute('aria-label', expanded ? 'Open navigation' : 'Close navigation');
    navigation?.classList.toggle('is-open', !expanded);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && menu) {
      menu.setAttribute('aria-expanded', 'false');
      menu.setAttribute('aria-label', 'Open navigation');
      navigation?.classList.remove('is-open');
    }
  });

  const dialog = document.querySelector('#gallery-dialog');
  const dialogImage = document.querySelector('#gallery-image');
  const caption = document.querySelector('#gallery-caption');
  if (dialog instanceof HTMLDialogElement && dialogImage instanceof HTMLImageElement) {
    document.querySelectorAll('.gallery-item').forEach((item) => {
      item.addEventListener('click', () => {
        dialogImage.src = item.getAttribute('data-image') || '';
        dialogImage.alt = item.getAttribute('data-caption') || 'Bakery photograph';
        if (caption) caption.textContent = dialogImage.alt;
        dialog.showModal();
      });
    });
    dialog.querySelector('.dialog-close')?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (event) => {
      if (event.target === dialog) {
        const bounds = dialog.getBoundingClientRect();
        if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
      }
    });
  }

  const form = document.querySelector('#enquiry-form');
  const dateField = document.querySelector('#needed-date');
  if (dateField instanceof HTMLInputElement) {
    const now = new Date();
    const localDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    dateField.min = localDate;
  }
  if (form instanceof HTMLFormElement) {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      const name = String(data.get('customerName') || '').trim();
      if (!name) {
        const input = form.querySelector('#customer-name');
        if (input instanceof HTMLInputElement) {
          input.setCustomValidity('Please enter your name.');
          input.reportValidity();
          input.addEventListener('input', () => input.setCustomValidity(''), { once: true });
        }
        return;
      }
      const lines = [
        `Hi ${form.dataset.bakery || 'Crumb & Co.'}! My name is ${name}.`,
        "I'd like to enquire about an order:",
        '',
        `Bake: ${data.get('product')}`,
        `Quantity: ${data.get('quantity')} (in the listed product unit)`
      ];
      if (data.get('occasion')) lines.push(`Occasion: ${data.get('occasion')}`);
      if (data.get('date')) lines.push(`Preferred date: ${data.get('date')}`);
      const details = String(data.get('message') || '').trim();
      if (details) lines.push('', `Details: ${details}`);
      lines.push('', 'Please let me know about availability, the final price and collection. Thank you!');
      const message = lines.join('\n');
      const preview = document.querySelector('#message-preview');
      const messageText = document.querySelector('#prepared-message');
      const sendLink = document.querySelector('#send-whatsapp');
      const status = document.querySelector('#whatsapp-status');
      if (messageText) messageText.textContent = message;
      if (preview instanceof HTMLElement) preview.hidden = false;
      if (sendLink instanceof HTMLAnchorElement) {
        if (form.dataset.whatsappBase) {
          const url = new URL(form.dataset.whatsappBase);
          url.searchParams.set('text', message);
          sendLink.href = url.toString();
          sendLink.removeAttribute('aria-disabled');
          sendLink.hidden = false;
          if (status) status.textContent = 'WhatsApp will open with this message. You choose when to send it.';
        } else {
          sendLink.removeAttribute('href');
          sendLink.hidden = true;
          if (status) status.textContent = 'Your message is prepared. Sending is not enabled in this sample: the bakery owner must configure Bakery:WhatsAppNumber in appsettings.json.';
        }
      }
      preview?.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'nearest' });
    });
  }
});
