#!/usr/bin/env python3
"""Package this MVC website for Visual Studio with its local photography."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os
import shutil
import zipfile
import requests
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
DESTINATION = Path('/home/ubuntu/bakery-delivery/CrumbCo')
ARCHIVE = Path('/home/ubuntu/CrumbCo-VisualStudio2022.zip')
PREFIX = '/manus-storage/async-images/RPKnmC5elonVPRo3HcOCiF/'
NAMES = {1: 'hero', 2: 'cake', 3: 'bread', 4: 'cupcakes', 5: 'pastries'}
SKIP = {'.git', 'bin', 'obj', 'tools', 'node_modules', 'app.config.ts', 'TODO.md', '.DS_Store'}

DESTINATION.mkdir(parents=True, exist_ok=True)
for source in ROOT.rglob('*'):
    relative = source.relative_to(ROOT)
    if any(part in SKIP or part == '.env' or part.startswith('.env.') for part in relative.parts):
        continue
    target = DESTINATION / relative
    if source.is_file():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

api_url = os.environ['MANUS_API_URL'].rstrip('/')
api_key = os.environ['MANUS_API_KEY']

def download(item):
    index, name = item
    key = PREFIX.removeprefix('/manus-storage/') + f'image-{index}.webp'
    response = requests.get(
        api_url + '/v1/storage/presign/get',
        params={'path': key},
        headers={'Authorization': 'Bearer ' + api_key},
        timeout=30,
    )
    if response.status_code != 200 or not response.json().get('url'):
        raise RuntimeError(f'Cannot obtain photo export for {name}: HTTP {response.status_code}')
    image_response = requests.get(response.json()['url'], timeout=60)
    if image_response.status_code != 200:
        raise RuntimeError(f'Cannot download {name} photo: HTTP {image_response.status_code}')
    target = DESTINATION / 'wwwroot' / 'images' / f'{name}.webp'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(image_response.content)
    with Image.open(target) as image:
        image.verify()
    with Image.open(target) as image:
        if image.width < 600 or image.height < 600:
            raise RuntimeError(f'Photo {name} appears not ready at {image.size}')
        if image.format != 'WEBP':
            image.convert('RGB').save(target, 'WEBP', quality=90)
    return name, target.stat().st_size

with ThreadPoolExecutor(max_workers=5) as pool:
    for name, size in pool.map(download, NAMES.items()):
        print(f'Included {name} photograph ({size} bytes).', flush=True)

for source in DESTINATION.rglob('*'):
    if source.is_file() and source.suffix in {'.cs', '.cshtml', '.md'}:
        text = source.read_text()
        if source.name == 'ProductCatalog.cs':
            text = text.replace('private const string ImagePrefix = "' + PREFIX + '";', 'private const string ImagePrefix = "/images/";')
            for index, name in NAMES.items():
                text = text.replace(f'"image-{index}.webp"', f'"{name}.webp"')
        else:
            for index, name in NAMES.items():
                text = text.replace(PREFIX + f'image-{index}.webp', f'/images/{name}.webp')
        source.write_text(text)

with zipfile.ZipFile(ARCHIVE, 'w', zipfile.ZIP_DEFLATED) as archive:
    for source in DESTINATION.rglob('*'):
        if source.is_file():
            archive.write(source, Path('CrumbCo') / source.relative_to(DESTINATION))
print(f'Portable Visual Studio project: {ARCHIVE}', flush=True)
