namespace CrumbCo.Models;

public sealed class BakerySettings
{
    public string Name { get; set; } = "Crumb & Co.";

    public string Tagline { get; set; } = "Handcrafted bakes, made with love.";

    public string Phone { get; set; } = "Your bakery phone number";

    public string Email { get; set; } = "hello@example.com";

    public string Address { get; set; } = "12 Baker Street";

    public string City { get; set; } = "Cape Town, South Africa";

    public string WhatsAppNumber { get; set; } = string.Empty;

    public string PublicOrigin { get; set; } = string.Empty;

    public bool IsDemo { get; set; } = true;
}
