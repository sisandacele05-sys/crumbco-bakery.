namespace CrumbCo.Models;

public sealed class Product
{
    public string Id { get; init; } = string.Empty;

    public string Name { get; init; } = string.Empty;

    public string Category { get; init; } = string.Empty;

    public string Description { get; init; } = string.Empty;

    public string ImageUrl { get; init; } = string.Empty;

    public string PriceUnit { get; init; } = string.Empty;

    public string Badge { get; init; } = string.Empty;

    public decimal Price { get; init; }

    public bool Featured { get; init; }
}
