using CrumbCo.Models;

namespace CrumbCo.Services;

public sealed class ProductCatalog
{
    private const string ImagePrefix = "/manus-storage/async-images/RPKnmC5elonVPRo3HcOCiF/";

    public IReadOnlyList<Product> Products { get; } = new List<Product>
    {
        new()
        {
            Id = "vanilla-celebration-cake",
            Name = "Vanilla celebration cake",
            Category = "Cakes",
            Description = "A light vanilla sponge layered with silky buttercream and finished for celebrations.",
            ImageUrl = ImagePrefix + "image-2.webp",
            Price = 380m,
            PriceUnit = "per cake",
            Badge = "Signature",
            Featured = true
        },
        new()
        {
            Id = "chocolate-celebration-cake",
            Name = "Chocolate celebration cake",
            Category = "Cakes",
            Description = "Rich chocolate sponge with smooth cocoa buttercream and a generous finish.",
            ImageUrl = ImagePrefix + "image-2.webp",
            Price = 420m,
            PriceUnit = "per cake",
            Badge = "Crowd favourite",
            Featured = false
        },
        new()
        {
            Id = "artisan-sourdough",
            Name = "Artisan sourdough",
            Category = "Bread",
            Description = "Naturally leavened country loaf with a crisp crust and tender, open crumb.",
            ImageUrl = ImagePrefix + "image-3.webp",
            Price = 55m,
            PriceUnit = "per loaf",
            Badge = "Baked fresh",
            Featured = true
        },
        new()
        {
            Id = "seeded-sourdough",
            Name = "Seeded sourdough",
            Category = "Bread",
            Description = "Naturally leavened sourdough rolled in a wholesome mix of toasted seeds.",
            ImageUrl = ImagePrefix + "image-3.webp",
            Price = 65m,
            PriceUnit = "per loaf",
            Badge = "Wholesome",
            Featured = false
        },
        new()
        {
            Id = "vanilla-cloud-cupcakes",
            Name = "Vanilla cloud cupcakes",
            Category = "Cupcakes",
            Description = "Six fluffy vanilla cupcakes topped with a soft swirl of vanilla frosting.",
            ImageUrl = ImagePrefix + "image-4.webp",
            Price = 150m,
            PriceUnit = "box of 6",
            Badge = "Party pick",
            Featured = true
        },
        new()
        {
            Id = "berry-blush-cupcakes",
            Name = "Berry blush cupcakes",
            Category = "Cupcakes",
            Description = "Six berry-kissed cupcakes finished with blush-pink buttercream swirls.",
            ImageUrl = ImagePrefix + "image-4.webp",
            Price = 165m,
            PriceUnit = "box of 6",
            Badge = "Seasonal",
            Featured = false
        },
        new()
        {
            Id = "butter-croissant",
            Name = "Butter croissant",
            Category = "Pastries",
            Description = "Classic all-butter pastry with golden layers, a crisp shell, and soft centre.",
            ImageUrl = ImagePrefix + "image-5.webp",
            Price = 28m,
            PriceUnit = "each",
            Badge = "Morning favourite",
            Featured = true
        },
        new()
        {
            Id = "almond-croissant",
            Name = "Almond croissant",
            Category = "Pastries",
            Description = "A flaky butter croissant filled with almond frangipane and toasted almonds.",
            ImageUrl = ImagePrefix + "image-5.webp",
            Price = 35m,
            PriceUnit = "each",
            Badge = "Bakery classic",
            Featured = false
        }
    }.AsReadOnly();
}
