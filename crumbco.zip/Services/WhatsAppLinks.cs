using System.Text;

namespace CrumbCo.Services;

public static class WhatsAppLinks
{
    public static string? Build(string? number, string message)
    {
        if (string.IsNullOrWhiteSpace(number))
        {
            return null;
        }

        var trimmedNumber = number.Trim();
        var digits = new StringBuilder(trimmedNumber.Length);

        for (var index = 0; index < trimmedNumber.Length; index++)
        {
            var character = trimmedNumber[index];

            if (character is >= '0' and <= '9')
            {
                digits.Append(character);
                continue;
            }

            if (character == '+' && index == 0)
            {
                continue;
            }

            if (character is ' ' or '-' or '(' or ')' or '.')
            {
                continue;
            }

            return null;
        }

        if (digits.Length is < 8 or > 15)
        {
            return null;
        }

        return $"https://wa.me/{digits}?text={Uri.EscapeDataString(message)}";
    }
}
